import * as i0 from '@angular/core';
import { Signal, OnInit, WritableSignal, InjectionToken, AfterViewChecked, PipeTransform, Provider, Type, ClassProvider, FactoryProvider } from '@angular/core';
import { Observable, Subject } from 'rxjs';

declare function _<T extends string | string[]>(key: T): T;

type InterpolateFunction = (params?: InterpolationParameters) => string;
declare abstract class TranslateParser {
    /**
     * Interpolates a string to replace parameters
     * "This is a {{ key }}" ==> "This is a value", with params = { key: "value" }
     * @param expr
     * @param params
     */
    abstract interpolate(expr: InterpolateFunction | string, params?: InterpolationParameters): string | undefined;
}
declare class TranslateDefaultParser extends TranslateParser {
    templateMatcher: RegExp;
    interpolate(expr: InterpolateFunction | string, params?: InterpolationParameters): string | undefined;
    protected interpolateFunction(fn: InterpolateFunction, params?: InterpolationParameters): string;
    protected interpolateString(expr: string, params?: InterpolationParameters): string;
    /**
     * Returns the replacement for an interpolation parameter
     * @params:
     */
    protected getInterpolationReplacement(params: InterpolationParameters, key: string): string | undefined;
    /**
     * Converts a value into a useful string representation.
     * @param value The value to format.
     * @returns A string representation of the value.
     */
    protected formatValue(value: unknown): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateDefaultParser, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslateDefaultParser>;
}

type InterpolationParameters = Record<string, any>;
type StrictTranslation = string | StrictTranslation[] | TranslationObject | undefined | null;
type Translation = StrictTranslation | any;
interface TranslationObject {
    [key: string]: StrictTranslation;
}
type InterpolatableTranslation = string | InterpolatableTranslation[] | InterpolateFunction | InterpolatableTranslationObject | undefined | null;
interface InterpolatableTranslationObject {
    [key: string]: InterpolatableTranslation;
}
type Language = string;
interface TranslationChangeEvent {
    translations: InterpolatableTranslationObject;
    lang: string;
}
interface LangChangeEvent {
    lang: string;
    translations: InterpolatableTranslationObject;
}
interface FallbackLangChangeEvent {
    lang: string;
    translations: InterpolatableTranslationObject;
}
declare abstract class ITranslateService {
    abstract readonly onTranslationChange: Observable<TranslationChangeEvent>;
    abstract readonly onLangChange: Observable<LangChangeEvent>;
    abstract readonly onFallbackLangChange: Observable<FallbackLangChangeEvent>;
    /**
     * A combined Observable that emits whenever translations might need to be refreshed.
     * This includes: language changes, translation updates for the current language,
     * and fallback language changes.
     */
    abstract readonly onTranslationRefresh: Observable<void>;
    abstract use(lang: Language): Observable<InterpolatableTranslationObject>;
    abstract setFallbackLang(lang: Language): Observable<InterpolatableTranslationObject>;
    abstract getFallbackLang(): Language | null;
    abstract addLangs(languages: Language[]): void;
    abstract getLangs(): readonly Language[];
    abstract reloadLang(lang: Language): Observable<InterpolatableTranslationObject>;
    abstract resetLang(lang: Language): void;
    abstract instant(key: string | string[], interpolateParams?: InterpolationParameters, lang?: Language): Translation;
    /**
     * Returns a Signal that provides the translated value and automatically updates
     * whenever the currentLang, fallbackLang, or the translations change.
     *
     * Parameters accept plain values or arrow functions. Signal reads inside
     * the function are tracked reactively. Signals themselves are also accepted
     * directly, since Signal<T> is callable.
     *
     * @param key - The translation key (or array of keys), a function returning one
     * @param params - Optional interpolation parameters, or a function returning them
     * @param lang - Optional language override, or a function returning one
     * @returns A Signal that emits the translated value
     */
    abstract translate(key: string | string[] | (() => string | string[]), params?: InterpolationParameters | (() => InterpolationParameters | undefined), lang?: Language | (() => Language | undefined)): Signal<Translation | TranslationObject>;
    abstract stream(key: string | string[], interpolateParams?: InterpolationParameters, lang?: Language): Observable<Translation>;
    abstract getStreamOnTranslationChange(key: string | string[], interpolateParams?: InterpolationParameters, lang?: Language): Observable<Translation>;
    abstract set(key: string, translation: string | TranslationObject, lang?: Language): void;
    abstract get(key: string | string[], interpolateParams?: InterpolationParameters, lang?: Language): Observable<Translation>;
    abstract setTranslation(lang: Language, translations: TranslationObject, shouldMerge?: boolean): void;
    abstract setCompiledTranslation(lang: Language, translations: InterpolatableTranslationObject, shouldMerge?: boolean): void;
    abstract getParsedResult(key: string | string[], interpolateParams?: InterpolationParameters, lang?: Language): StrictTranslation | Observable<StrictTranslation>;
    abstract getBrowserLang(): Language | undefined;
    abstract getBrowserCultureLang(): Language | undefined;
    /**
     * The current language as a reactive Signal.
     * Use `getCurrentLang()` for a non-reactive snapshot.
     */
    abstract readonly currentLang: Signal<Language | null>;
    /**
     * The fallback language as a reactive Signal.
     * Use `getFallbackLang()` for a non-reactive snapshot.
     */
    abstract readonly fallbackLang: Signal<Language | null>;
    /**
     * `true` while one or more language loads are in flight at this service
     * or any of its ancestors in the service hierarchy.
     *
     * Loading scope propagates DOWNWARD: a load triggered at the root marks
     * the root and all descendants as loading. A load triggered at a child
     * (e.g. a lazy-route bootstrap fetching its translations) marks only that
     * child's subtree. Siblings and ancestors are unaffected by a descendant's
     * loads.
     *
     * Drive a spinner by reading it from the service injected at the scope
     * where the spinner should live: root for an app-shell spinner, the
     * nearest child for a local spinner inside a lazy-loaded subtree.
     */
    abstract readonly isLoading: Signal<boolean>;
    /**
     * Returns the current language as a plain value (non-reactive).
     * Use `currentLang` signal for reactive usage.
     */
    abstract getCurrentLang(): Language | null;
    /**
     * Returns the loaded translations for the given language.
     */
    abstract getTranslations(language: Language): InterpolatableTranslationObject;
    /**
     * Returns the service this one inherits translations from, or `null` if
     * this is a root (a top-level service or an isolated subtree root).
     *
     * A `null` return means the service is the terminus of its translation
     * fallback chain — equivalent to "is this a root?".
     */
    abstract getParent(): ITranslateService | null;
    /**
     * Returns the root of this service's hierarchy — the topmost service in
     * the `getParent()` chain. For an isolated subtree, returns the subtree's
     * root (since `getParent()` returns `null` at the isolation boundary).
     *
     * A root service returns itself.
     */
    abstract getRoot(): ITranslateService;
}

/**
 * Returns a Signal with the translation for the given key, resolved against
 * the current language. Must be called in an Angular injection context.
 *
 * Parameters accept plain values or arrow functions. Signal reads inside
 * the function are tracked reactively. Signals themselves are also accepted
 * directly, since Signal<T> is callable.
 *
 * @example
 * greeting = translate('HELLO');
 *
 * @example
 * model = signal({ currentKey: 'HELLO' });
 * greeting = translate(() => this.model().currentKey);
 */
declare function translate(key: string | string[] | (() => string | string[]), params?: InterpolationParameters | (() => InterpolationParameters | undefined), lang?: Language | (() => Language | undefined)): Signal<Translation | TranslationObject>;

declare class TranslateBlockContext {
    $implicit: (key: string, params?: InterpolationParameters) => Translation;
    constructor($implicit: (key: string, params?: InterpolationParameters) => Translation);
}
declare class TranslateBlockDirective implements OnInit {
    private templateRef;
    private viewContainer;
    private translateService;
    ngOnInit(): void;
    static ngTemplateContextGuard(_dir: TranslateBlockDirective, _ctx: unknown): _ctx is TranslateBlockContext;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateBlockDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TranslateBlockDirective, "[translateBlock]", never, {}, {}, never, never, true, never>;
}

/**
 * In-flight load registry — one entry per language currently being loaded.
 * Backed by a signal so `isLoading` can derive reactively from its contents.
 *
 * Invariants:
 * - Entries added by `loadAndCompileTranslations` before subscribe.
 * - Entries removed by `loadAndCompileTranslations`'s `tap` on the success
 *   path (synchronously between store update and subscriber notification, so
 *   subscribers observe this language gone from the registry — and
 *   `isLoading()` flips false if no other load is in flight) and by the
 *   `shareReplay`'d Observable's `finalize` for error / sync-throw /
 *   last-subscriber-unsubscribe paths. The success-path finalize is a safe
 *   no-op (idempotent `clearIfOwner`).
 * - Same-language back-to-back loads dedup via the existing `shareReplay`; the
 *   registry stays at one entry per language regardless of subscriber count.
 *   `isLoading` therefore toggles `0 -> 1 -> 0` once per language load, not
 *   once per subscriber. Set-based, not count-based — matches user intent
 *   ("a language is loading" not "N callers asked").
 * - `clearIfOwner(lang, token)` only removes the entry if it still matches the
 *   original Observable token captured at `set()` time. Prevents stale-finalize
 *   races where an old load's `finalize` would clobber a newer load's entry
 *   (e.g. `resetLang` followed by `reloadLang` while the old load is still
 *   mid-flight).
 * - `clear(lang)` is unconditional — used by `resetLang` to forcibly drop
 *   ownership regardless of which load owns the entry.
 *
 * Internal to the package — not re-exported from `public-api.ts`.
 */
declare class LoadingTranslationsRegistry {
    private state;
    /** Reactive — `true` while at least one load is in flight. */
    readonly hasAny: Signal<boolean>;
    /** `true` while THIS language is being loaded on this instance. */
    isLoading(lang: Language): boolean;
    get(lang: Language): Observable<InterpolatableTranslationObject> | undefined;
    set(lang: Language, obs: Observable<InterpolatableTranslationObject>): void;
    /** Unconditional clear. Used by `resetLang` to forcibly drop the entry. */
    clear(lang: Language): void;
    /**
     * Token-aware clear. Used by `loadAndCompileTranslations`'s `finalize` so
     * an old load's `finalize` cannot clobber a newer load's entry.
     */
    clearIfOwner(lang: Language, token: Observable<InterpolatableTranslationObject>): void;
}

declare abstract class TranslateCompiler {
    abstract compile(value: string, lang: string): InterpolatableTranslation;
    abstract compileTranslations(translations: TranslationObject, lang: string): InterpolatableTranslationObject;
}
/**
 * This compiler is just a placeholder that does nothing; in case you don't need a compiler at all
 */
declare class TranslateNoOpCompiler extends TranslateCompiler {
    compile(value: string, lang: string): string | InterpolateFunction;
    compileTranslations(translations: TranslationObject, lang: string): InterpolatableTranslationObject;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateNoOpCompiler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslateNoOpCompiler>;
}

declare abstract class TranslateLoader {
    abstract getTranslation(lang: string): Observable<TranslationObject>;
}
/**
 * This loader is just a placeholder that does nothing; in case you don't need a loader at all
 */
declare class TranslateNoOpLoader extends TranslateLoader {
    getTranslation(lang: string): Observable<TranslationObject>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateNoOpLoader, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslateNoOpLoader>;
}

type DeepReadonly<T> = {
    readonly [K in keyof T]: T[K] extends object ? DeepReadonly<T[K]> : T[K];
};
declare class TranslateStore {
    private readonly _translations;
    readonly translations: Signal<Record<Language, InterpolatableTranslationObject>>;
    private readonly _languages;
    readonly languages: Signal<Language[]>;
    private readonly _lastTranslationChange;
    readonly lastTranslationChange: Signal<TranslationChangeEvent | null>;
    private readonly _translationChange$;
    readonly translationChange$: Observable<TranslationChangeEvent>;
    constructor();
    getTranslations(language: Language): DeepReadonly<InterpolatableTranslationObject>;
    setTranslations(language: Language, translations: InterpolatableTranslationObject, extend: boolean): void;
    getLanguages(): readonly Language[];
    addLanguages(langs: Language[]): void;
    hasTranslationFor(lang: string): boolean;
    deleteTranslations(lang: string): void;
    getTranslationValue(language: Language, key: string): InterpolatableTranslation;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateStore, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslateStore>;
}

/**
 * Configuration object for the translation service.
 *
 * Provides options to customize translation behavior, including setting the primary language,
 * specifying a fallback language, and other deprecated flags for legacy support.
 */
interface TranslateServiceConfig {
    lang?: Language;
    fallbackLang?: Language | null;
    isRoot: boolean;
}
declare const TRANSLATE_SERVICE_CONFIG: InjectionToken<TranslateServiceConfig>;
declare class TranslateService implements ITranslateService {
    protected readonly loadingTranslations: LoadingTranslationsRegistry;
    protected lastUseLanguage: Language | null;
    protected currentLoader: TranslateLoader;
    protected compiler: TranslateCompiler;
    protected parser: TranslateParser;
    protected missingTranslationHandler: MissingTranslationHandler;
    protected store: TranslateStore;
    private readonly destroyRef;
    protected readonly parent: TranslateService | null;
    protected get isRoot(): boolean;
    protected _onLangChange: Subject<LangChangeEvent>;
    protected _onFallbackLangChange: Subject<FallbackLangChangeEvent>;
    protected _currentLang: WritableSignal<Language | null>;
    protected _fallbackLang: WritableSignal<Language | null>;
    private _onTranslationRefresh;
    private _isLoading;
    /**
     * Returns the root of this service's hierarchy — the topmost service in
     * the `getParent()` chain. For an isolated subtree, returns the subtree's
     * root (since `parent === null` at the isolation boundary).
     *
     * A root service returns itself. Equivalent to walking `getParent()` until
     * it returns `null`, but provided as a convenience.
     */
    getRoot(): TranslateService;
    /**
     * Returns the service this one inherits translations from, or `null` if
     * this is a root (a top-level service or an isolated subtree root).
     *
     * A `null` return means the service is the terminus of its translation
     * fallback chain — equivalent to "is this a root?".
     */
    getParent(): TranslateService | null;
    /**
     * The language most recently requested via `use()`. Always read from the
     * root, because `use()` delegates to the root (`parent!.use(lang)`) and only
     * the root ever assigns `lastUseLanguage`. A child's own `lastUseLanguage`
     * stays `null`, so reading it directly would make `get()` miss the child's
     * in-flight load. `null` until the first `use()` runs.
     */
    protected getActiveRequestedLang(): Language | null;
    protected hasTranslationInChain(lang: Language): boolean;
    protected chainTranslationChange$(): Observable<TranslationChangeEvent>;
    /**
     * An Observable to listen to translation change events
     * onTranslationChange.subscribe((params: TranslationChangeEvent) => {
     *     // do something
     * });
     */
    get onTranslationChange(): Observable<TranslationChangeEvent>;
    /**
     * An Observable to listen to lang change events
     * onLangChange.subscribe((params: LangChangeEvent) => {
     *     // do something
     * });
     */
    get onLangChange(): Observable<LangChangeEvent>;
    /**
     * An Observable to listen to fallback lang change events
     * onFallbackLangChange.subscribe((params: FallbackLangChangeEvent) => {
     *     // do something
     * });
     */
    get onFallbackLangChange(): Observable<FallbackLangChangeEvent>;
    /**
     * A combined Observable that emits whenever translations might need to be refreshed.
     * This includes: language changes, translation updates for the current or fallback language,
     * and fallback language changes.
     */
    get onTranslationRefresh(): Observable<void>;
    constructor();
    /**
     * Sets the fallback language to use if a translation is not found in the
     * current language
     */
    setFallbackLang(lang: Language): Observable<InterpolatableTranslationObject>;
    /**
     * Signal that is `true` while one or more language loads are in flight at
     * this service or any of its ancestors in the service hierarchy.
     *
     * Loading scope propagates DOWNWARD: a load triggered at the root marks
     * the root and all descendants as loading. A load triggered at a child
     * (e.g. a lazy-route bootstrap fetching its translations) marks only that
     * child's subtree. Siblings and ancestors are unaffected by a descendant's
     * loads.
     *
     * Drive a spinner by reading it from the service injected at the scope
     * where the spinner should live: root for an app-shell spinner, the
     * nearest child for a local spinner inside a lazy-loaded subtree.
     */
    get isLoading(): Signal<boolean>;
    /**
     * Changes the lang currently used
     */
    use(lang: Language): Observable<InterpolatableTranslationObject>;
    /**
     * Retrieves the given translations
     */
    protected loadOrExtendLanguage(lang: Language): Observable<InterpolatableTranslationObject> | undefined;
    /**
     * @returns The loaded translations for the given language
     */
    getTranslations(language: Language): DeepReadonly<InterpolatableTranslationObject>;
    /**
     * Changes the current lang
     */
    protected changeLang(lang: Language): void;
    getCurrentLang(): Language | null;
    /**
     * Loads translations for `lang` via the configured `TranslateLoader`,
     * compiles them, and stores the result. Tracking via the protected
     * `loadingTranslations` registry happens automatically.
     *
     * Subclasses that override this method bypass `isLoading` tracking
     * unless they call `this.loadingTranslations.set(lang, obs)` and arrange
     * a token-aware finalize (`this.loadingTranslations.clearIfOwner(lang, obs)`)
     * from the override.
     */
    protected loadAndCompileTranslations(lang: Language): Observable<InterpolatableTranslationObject>;
    /**
     * Manually sets an object of translations for a given language,
     * passing it through the configured {@link TranslateCompiler} first.
     *
     * If you already have translations in their final compiled form
     * (e.g. interpolation functions produced at build time), use
     * {@link setCompiledTranslation} instead — it stores the data
     * directly and skips the compiler.
     */
    setTranslation(lang: Language, translations: TranslationObject, shouldMerge?: boolean): void;
    /**
     * Stores an already-compiled translation object for the given language,
     * bypassing the configured {@link TranslateCompiler}.
     *
     * Use this when you have translations in their final, interpolator-ready
     * form — e.g. interpolation functions produced at build time. For raw
     * translations that still need to go through the compiler, use
     * {@link setTranslation} instead.
     */
    setCompiledTranslation(lang: Language, translations: InterpolatableTranslationObject, shouldMerge?: boolean): void;
    getLangs(): readonly Language[];
    /**
     * Add available languages
     */
    addLangs(languages: Language[]): void;
    protected getParsedResultForKey(key: string, interpolateParams?: InterpolationParameters, lang?: Language): StrictTranslation | Observable<StrictTranslation>;
    protected getMissingTranslationHandler(): MissingTranslationHandler;
    /**
     * Gets the fallback language. null if none is defined
     */
    getFallbackLang(): Language | null;
    protected getTextToInterpolate(key: string, lang?: Language): InterpolatableTranslation | undefined;
    protected runInterpolation(translations: InterpolatableTranslation, interpolateParams?: InterpolationParameters): StrictTranslation;
    protected runInterpolationOnArray(translations: InterpolatableTranslation, interpolateParams: InterpolationParameters | undefined): StrictTranslation[];
    protected runInterpolationOnDict(translations: InterpolatableTranslationObject, interpolateParams: InterpolationParameters | undefined): TranslationObject;
    /**
     * Returns the parsed result of the translations
     */
    getParsedResult(key: string | string[], interpolateParams?: InterpolationParameters, lang?: Language): StrictTranslation | Observable<StrictTranslation>;
    protected getParsedResultForArray(key: string[], interpolateParams: InterpolationParameters | undefined, lang?: Language): TranslationObject | Observable<TranslationObject>;
    /**
     * Gets the translated value of a key (or an array of keys)
     * @returns the translated key, or an object of translated keys
     */
    get(key: string | string[], interpolateParams?: InterpolationParameters, lang?: Language): Observable<Translation>;
    /**
     * Returns a stream of translated values of a key (or an array of keys) which updates
     * whenever the translation changes.
     * @returns A stream of the translated key, or an object of translated keys
     */
    getStreamOnTranslationChange(key: string | string[], interpolateParams?: InterpolationParameters, lang?: Language): Observable<Translation>;
    /**
     * Returns a stream of translated values of a key (or an array of keys) which updates
     * whenever the language changes, the requested language's translations are
     * (re)loaded, or the explicitly-requested `lang` argument's translations change.
     *
     * Without `lang`: re-emits on `onLangChange` (active-language switches via
     * {@link use}). With `lang`: also re-emits when translations for that specific
     * language are loaded or updated via `store.translationChange$`, so an
     * explicit `stream("KEY", undefined, "de")` updates once "de" finishes
     * loading.
     *
     * @returns A stream of the translated key, or an object of translated keys
     */
    stream(key: string | string[], interpolateParams?: InterpolationParameters, lang?: Language): Observable<Translation>;
    /**
     * Returns a translation instantly from the internal state of loaded translation.
     * All rules regarding the current language, the preferred language of even fallback languages
     * will be used except any promise handling.
     *
     * When `lang` is provided, the lookup goes directly to the specified language,
     * bypassing the current language and fallback chain.
     */
    instant(key: string | string[], interpolateParams?: InterpolationParameters, lang?: Language): Translation;
    private warnedUnloadedInstantLangs;
    private warnUnloadedInstantLang;
    /**
     * Returns a Signal that provides the translated value and automatically
     * updates when the language changes or translations are reloaded.
     *
     * Parameters accept plain values or arrow functions. Signal reads inside
     * the function are tracked reactively. Signals themselves are also
     * accepted directly, since Signal<T> is callable.
     *
     * @param key The translation key (or array of keys), a function returning one
     * @param params Optional interpolation parameters, or a function returning them
     * @param lang Optional language override, or a function returning one
     * @returns A Signal that emits the translated value(s)
     *
     * @example
     * // Static key
     * greeting = this.translate.translate('HELLO');
     *
     * @example
     * // Derived key from another signal (no separate computed needed)
     * model = signal({ currentKey: 'HELLO' });
     * greeting = this.translate.translate(() => this.model().currentKey);
     *
     * @example
     * // Multi-key lookup
     * labels = this.translate.translate(['SAVE', 'CANCEL']);
     */
    translate(key: string | string[] | (() => string | string[]), params?: InterpolationParameters | (() => InterpolationParameters | undefined), lang?: Language | (() => Language | undefined)): Signal<Translation | TranslationObject>;
    protected keyToObject(key: string | string[]): string | Record<string, string>;
    /**
     * Sets the translated value of a key, after compiling it
     */
    set(key: string, translation: string | TranslationObject, lang?: Language): void;
    /**
     * Allows reloading the lang file from the file
     */
    reloadLang(lang: Language): Observable<InterpolatableTranslationObject>;
    /**
     * Deletes stored translations for `lang` and clears the in-flight registry
     * entry — `isLoading()` flips to `false` immediately on this service.
     *
     * Does NOT cancel the underlying network call: if the loader is mid-flight
     * when this method returns, the request can still complete and `tap()`
     * translations back into the store. To replace state and re-fetch
     * deterministically, follow with `reloadLang(lang)`.
     */
    resetLang(lang: Language): void;
    /**
     * Returns the language code name from the browser, e.g. "de"
     */
    static getBrowserLang(): Language | undefined;
    /**
     * Returns the culture language code name from the browser, e.g. "de-DE"
     */
    static getBrowserCultureLang(): Language | undefined;
    getBrowserLang(): Language | undefined;
    getBrowserCultureLang(): Language | undefined;
    /**
     * The current language as a reactive Signal.
     * Use `getCurrentLang()` for a non-reactive snapshot.
     */
    get currentLang(): Signal<Language | null>;
    /**
     * The fallback language as a reactive Signal.
     * Use `getFallbackLang()` for a non-reactive snapshot.
     */
    get fallbackLang(): Signal<Language | null>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslateService>;
}

interface MissingTranslationHandlerParams {
    /**
     * the key that's missing in translation files
     */
    key: string;
    /**
     * an instance of the service that was unable to translate the key.
     */
    translateService: TranslateService;
    /**
     * interpolation params that were passed along for translating the given key.
     */
    interpolateParams?: object;
}
declare abstract class MissingTranslationHandler {
    /**
     * A function that handles missing translations.
     *
     * @param params context for resolving a missing translation
     * @returns a value or an observable
     *
     * If it returns a value, then this value is used.
     * If it returns an observable, the value returned by this observable will be used (except if the method was "instant").
     * If it returns undefined, the key will be used as a value
     */
    abstract handle(params: MissingTranslationHandlerParams): StrictTranslation | Observable<StrictTranslation>;
}
/**
 * This handler is just a placeholder that does nothing; in case you don't need a missing translation handler at all
 */
declare class DefaultMissingTranslationHandler implements MissingTranslationHandler {
    handle(params: MissingTranslationHandlerParams): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DefaultMissingTranslationHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DefaultMissingTranslationHandler>;
}

declare class TranslateDirective implements AfterViewChecked {
    private translateService;
    private element;
    private destroyRef;
    private changeDetectorRef;
    private injector;
    private key;
    private currentParams?;
    private keySignal;
    private paramsSignal;
    private translationSignal;
    private effectCreated;
    private contentKeyHandler;
    set translate(key: string);
    set translateParams(params: InterpolationParameters);
    constructor();
    ngAfterViewChecked(): void;
    private setupEffect;
    private writeTranslationToDOM;
    private writeToDOM;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TranslateDirective, "[translate],[ngx-translate]", never, { "translate": { "alias": "translate"; "required": false; }; "translateParams": { "alias": "translateParams"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TranslatePipe implements PipeTransform {
    private translateService;
    private cachedSignal;
    private lastKey;
    private lastParams;
    transform(query: string | undefined | null, ...args: any[]): any;
    private parseArgs;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<TranslatePipe, "translate", true>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslatePipe>;
}

/**
 * Provider shape accepted by the four plugin slots on
 * {@link RootTranslateServiceConfig} and {@link ChildTranslateServiceConfig}.
 *
 * Accepts any Angular {@link Provider} — including bare classes (TypeProvider)
 * and bare factory functions. When a bare class or factory is passed, it is
 * automatically wrapped by the corresponding `provideTranslate*` helper so it
 * is registered under the correct DI token.
 */
type TranslateProvider = Provider | (() => unknown);
interface TranslateProviders {
    loader?: TranslateProvider;
    compiler?: TranslateProvider;
    parser?: TranslateProvider;
    missingTranslationHandler?: TranslateProvider;
}
type ChildTranslateServiceConfig = Partial<TranslateProviders>;
interface RootTranslateServiceConfig extends ChildTranslateServiceConfig {
    fallbackLang?: Language;
    lang?: Language;
}
declare function provideTranslateLoader(loader: Type<TranslateLoader>): ClassProvider;
declare function provideTranslateLoader(factory: () => TranslateLoader): FactoryProvider;
declare function provideTranslateCompiler(compiler: Type<TranslateCompiler>): ClassProvider;
declare function provideTranslateCompiler(factory: () => TranslateCompiler): FactoryProvider;
declare function provideTranslateParser(parser: Type<TranslateParser>): ClassProvider;
declare function provideTranslateParser(factory: () => TranslateParser): FactoryProvider;
declare function provideMissingTranslationHandler(handler: Type<MissingTranslationHandler>): ClassProvider;
declare function provideMissingTranslationHandler(factory: () => MissingTranslationHandler): FactoryProvider;
declare function provideTranslateService(config?: RootTranslateServiceConfig): Provider[];
declare function provideChildTranslateService(config?: ChildTranslateServiceConfig): Provider[];

/**
 * Determines if two objects or two values are equivalent.
 *
 * Two objects or values are considered equivalent if at least one of the following is true:
 *
 * * Both objects or values pass `===` comparison.
 * * Both objects or values are of the same type and all of their properties are equal by
 *   comparing them with `equals`.
 *
 * @param o1 Object or value to compare.
 * @param o2 Object or value to compare.
 * @returns true if arguments are equal.
 */
declare function equals(o1: unknown, o2: unknown): boolean;
declare function isDefinedAndNotNull<T>(value: T | null | undefined): value is T;
declare function isDefined<T>(value: T | null | undefined): value is T | null;
declare function isDict(value: unknown): value is InterpolatableTranslationObject;
declare function isObject(value: unknown): value is Record<string, unknown>;
declare function isArray(value: unknown): value is unknown[];
declare function isString(value: unknown): value is string;
declare function isFunction(value: unknown): boolean;
declare function mergeDeep(target: Readonly<unknown>, source: Readonly<unknown>): any;
/**
 * Retrieves a value from a nested object using a dot-separated key path.
 *
 * Example usage:
 * ```ts
 * getValue({ key1: { keyA: 'valueI' }}, 'key1.keyA'); // returns 'valueI'
 * ```
 *
 * @param target The source object from which to retrieve the value.
 * @param key Dot-separated key path specifying the value to retrieve.
 * @returns The value at the specified key path, or `undefined` if not found.
 */
declare function getValue(target: unknown, key: string): unknown;
/**
 * Sets a value on object using a dot separated key.
 * Returns a clone of the object without modifying it
 * insertValue({a:{b:{c: "test"}}}, 'a.b.c', "test2") ==> {a:{b:{c: "test2"}}}
 * @param target an object
 * @param key E.g. "a.b.c"
 * @param value to set
 */
declare function insertValue<T>(target: Readonly<T>, key: string, value: unknown): T;

export { DefaultMissingTranslationHandler, ITranslateService, MissingTranslationHandler, TRANSLATE_SERVICE_CONFIG, TranslateBlockContext, TranslateBlockDirective, TranslateCompiler, TranslateDefaultParser, TranslateDirective, TranslateLoader, TranslateNoOpCompiler, TranslateNoOpLoader, TranslateParser, TranslatePipe, TranslateService, TranslateStore, _, equals, getValue, insertValue, isArray, isDefined, isDefinedAndNotNull, isDict, isFunction, isObject, isString, mergeDeep, provideChildTranslateService, provideMissingTranslationHandler, provideTranslateCompiler, provideTranslateLoader, provideTranslateParser, provideTranslateService, translate };
export type { ChildTranslateServiceConfig, DeepReadonly, FallbackLangChangeEvent, InterpolatableTranslation, InterpolatableTranslationObject, InterpolateFunction, InterpolationParameters, LangChangeEvent, Language, MissingTranslationHandlerParams, RootTranslateServiceConfig, StrictTranslation, TranslateProvider, TranslateProviders, TranslateServiceConfig, Translation, TranslationChangeEvent, TranslationObject };
